/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.analizadorlexico.backend.exceptions;

/**
 *
 * @author edu
 */
public class CampoVacioException extends Exception {

    public CampoVacioException() {
        super("el campo está vacio");
    }
    
}
