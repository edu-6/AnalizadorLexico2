/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.analizadorlexico;
import com.mycompany.analizadorlexico.backend.frontend.AnalizadorFrame;

/**
 *
 * @author edu
 */
public class AnalizadorLexico {

    public static void main(String[] args) {
        AnalizadorFrame frame = new AnalizadorFrame();
        frame.setVisible(true);
    }
}
